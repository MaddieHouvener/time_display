from django.apps import AppConfig


class AppDisplayConfig(AppConfig):
    name = 'app_display'
